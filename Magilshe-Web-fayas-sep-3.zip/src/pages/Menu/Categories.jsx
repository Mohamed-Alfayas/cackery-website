export const Categories = [
    "All",
    "Birthday Cakes",
    "Muffins",
    "2 Tires Cakes",
    "Themed Cakes",
    "Fruit Cakes",
    "Gifts",
    "Chocolates",
    "Sweets & Dry Fruits",
    "Pizza",
  ];
  