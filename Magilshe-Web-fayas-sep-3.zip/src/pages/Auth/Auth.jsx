import React from 'react'
// import Login from './Login'
import SignUp from './SignUp'
// import OTPVerify from './OTPVerify'

const Auth = () => {
  return (
    <div>
      {/* <Login />
      <OTPVerify /> */}
      <SignUp />
    </div>
  )
}

export default Auth
